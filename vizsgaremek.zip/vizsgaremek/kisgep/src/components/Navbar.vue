<template>
  <nav class="navbar navbar-expand-lg" style="background-color: #80868d">
    <div class="container-fluid">
      <img src="@/assets/logo.png" alt="Logo" width="120" height="90" class="d-inline-block align-text-top" />
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <router-link class="nav-link" to="/">Főoldal</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/login">Bejelentkezés</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/register">Regisztráció</router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: 'NavBar'
};
</script>

<style scoped>
.nav-link {
  font-size: 1.5rem;
}
</style>
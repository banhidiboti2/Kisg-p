<template>
    <div class="container mt-5">
      <nav class="navbar navbar-expand-lg" style="background-color: #80868d">
        <div class="container-fluid">
          <img src="output-onlinepngtools (1).png" alt="Logo" width="120" height="90" class="d-inline-block align-text-top" />
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <router-link class="nav-link" to="/">Főoldal</router-link>
              </li>
              <li class="nav-item">
                <router-link class="nav-link" to="/login">Bejelentkezés</router-link>
              </li>
              <li class="nav-item">
                <router-link class="nav-link" to="/register">Regisztráció</router-link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
  
      <div class="card p-4 shadow-sm">
        <form @submit.prevent="handleLogin">
          <div class="mb-3">
            <label class="form-label">E-mail</label>
            <input v-model="email" type="email" class="form-control" placeholder="példa@gmail.com" required />
          </div>
  
          <div class="mb-3">
            <label class="form-label">Jelszó</label>
            <input v-model="password" type="password" class="form-control" placeholder="Jelszó" required />
          </div>
  
          <div class="mb-3">
            <a href="#" class="text-decoration-none">Elfelejtett jelszó <span class="text-primary">Kattints ide.</span></a>
          </div>
  
          <button type="submit" class="btn btn-warning w-100">Bejelentkezés</button>
        </form>
        
        <router-link to="/register" class="btn btn-outline-secondary w-100 mt-3">
          Még nincs fiókja? Regisztráljon itt!
        </router-link>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        email: '',
        password: ''
      };
    },
    methods: {
      handleLogin() {
        if (this.email && this.password) {
          alert('Sikeres bejelentkezés');
          this.$router.push('/');
        }
      }
    }
  };
  </script>
  
  <style scoped>
  .nav-link {
    font-size: 1.5rem;
  }
  </style>
  
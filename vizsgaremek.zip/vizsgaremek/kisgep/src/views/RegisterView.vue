<template>
    <div class="container mt-5">
      <nav class="navbar navbar-expand-lg" style="background-color: #80868d">
        <div class="container-fluid">
          <img src="output-onlinepngtools (1).png" alt="Logo" width="120" height="90" class="d-inline-block align-text-top" />
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <router-link class="nav-link" to="/">Főoldal</router-link>
              </li>
              <li class="nav-item">
                <router-link class="nav-link" to="/login">Bejelentkezés</router-link>
              </li>
              <li class="nav-item">
                <router-link class="nav-link" to="/register">Regisztráció</router-link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
  
      <div class="card p-4 shadow-sm">
        <h4 class="mb-4">Személyes adatok</h4>
        
        <form @submit.prevent="handleRegister">
          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label">Vezetéknév</label>
              <input v-model="lastName" type="text" class="form-control" placeholder="Vezetéknév" required />
            </div>
            <div class="col-md-6">
              <label class="form-label">Keresztnév</label>
              <input v-model="firstName" type="text" class="form-control" placeholder="Keresztnév" required />
            </div>
          </div>
  
          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label">Jelszó</label>
              <input v-model="password" type="password" class="form-control" placeholder="Jelszó" required />
            </div>
            <div class="col-md-6">
              <label class="form-label">Jelszó újra</label>
              <input v-model="confirmPassword" type="password" class="form-control" placeholder="Jelszó újra" required />
            </div>
          </div>
  
          <div class="mb-3">
            <label class="form-label">E-mail</label>
            <input v-model="email" type="email" class="form-control" placeholder="valaki@gmail.com" required />
          </div>
  
          <div class="mb-3">
            <label class="form-label">Telefonszám</label>
            <input v-model="phone" type="tel" class="form-control" pattern="[0-9]+" title="Csak számokat adjon meg" required />
          </div>
  
          <button type="submit" class="btn btn-warning w-100">Mentés</button>
        </form>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        confirmPassword: '',
        phone: ''
      };
    },
    methods: {
      handleRegister() {
        if (this.password !== this.confirmPassword) {
          alert('A jelszavak nem egyeznek!');
          return;
        }
        alert('Sikeres regisztráció');
        this.$router.push('/');
      }
    }
  };
  </script>
  
  <style scoped>
  .nav-link {
    font-size: 1.5rem;
  }
  </style>
  
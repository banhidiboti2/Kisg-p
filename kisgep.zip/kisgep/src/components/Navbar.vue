<template>
    <nav class="navbar navbar-expand-lg custom-navbar">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
          <img src="C:\Users\banhi\OneDrive\Desktop\kisgep\src\photos\logo.png" class="logo" alt="Logo">
        </a>
        <router-link class="nav-link" to="/">Főoldal</router-link>
        <div class="d-flex flex-grow-1 justify-content-center">
          <span class="navbar-text">
            Gépkölcsönzés
          </span>
        </div>
        <div class="d-flex justify-content-end">
          <ul class="navbar-nav">
            <li class="nav-item">
              <router-link class="nav-link" to="/login">Bejelentkezés</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/register">Regisztráció</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/basket">
                <img src="C:\Users\banhi\OneDrive\Desktop\kisgep\src\photos\basket.png" width="30" height="30" class="d-inline-block align-top" alt="Basket">
              </router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </template>
  
  <script>
  export default {
    name: 'Navbar'
  };
  </script>
  
  <style scoped>
  .navbar {
    padding: 10px;
    height: 70px; 
  }
  
  .custom-navbar {
    background-color: #858a91; 
  }
  
  .navbar-brand img.logo {
    height: 90px; 
    width: auto; 
  }
  
  .navbar-text {
    font-size: 1.5rem;
    font-weight: bold;
  }
  
  .nav-link {
    font-size: 1.5rem; 
    font-weight: bold;
  }
  
  .navbar-nav {
    display: flex;
    align-items: center;
  }
  
  .navbar-nav .nav-item {
    margin-left: 10px;
    margin-right: 10px;
  }
  
  .navbar-nav .nav-link img {
    display: block;
    margin: 0 auto;
  }
  </style>
<template>
  <div class="app-container">
    <nav class="navbar">
      <button
        @click="navigate('login')"
        :class="{ active: currentView === 'login' }"
      >
        Bejelentkezés
      </button>
      <button
        @click="navigate('register')"
        :class="{ active: currentView === 'register' }"
      >
        Regisztráció
      </button>
    </nav>
    <component :is="currentViewComponent"></component>
  </div>
</template>

<script>
import LoginView from './views/LoginView.vue';
import RegisterView from './views/RegisterView.vue';

export default {
  data() {
    return {
      currentView: 'login'
    };
  },
  computed: {
    currentViewComponent() {
      return this.currentView === 'login' ? LoginView : RegisterView;
    }
  },
  methods: {
    navigate(view) {
      this.currentView = view;
    }
  }
};
</script>

<style scoped>
.app-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  /* A soft, modern gradient for a high-end look */
  background: linear-gradient(135deg, #8e9eab, #eef2f3);
  padding: 20px;
}

.navbar {
  margin-bottom: 30px;
}

.navbar button {
  background: rgba(255, 255, 255, 0.8);
  border: none;
  padding: 10px 30px;
  margin: 0 10px;
  font-size: 16px;
  cursor: pointer;
  border-radius: 50px;
  transition: background 0.4s ease, transform 0.3s ease;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.navbar button:hover {
  background: rgba(255, 255, 255, 1);
  transform: translateY(-2px);
}

.navbar button.active {
  background: #f1c40f; /* Elegant gold accent */
  color: #fff;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}
</style>

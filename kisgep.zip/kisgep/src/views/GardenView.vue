<template>
  <div class="container mx-auto p-4">
    <div class="flex justify-between items-center mb-4">
      <router-link to="/" class="back-button">Vissza</router-link>
      <h1 class="text-2xl font-bold">Kerti Gépek</h1>
    </div>

    <div class="grid grid-cols-3 gap-4">
      <div v-for="(item, index) in items" :key="index" class="border border-gray-300 p-4 text-center">
        <img :src="item.image" alt="Gép" class="product-image mx-auto mb-2">
        <p class="font-semibold">{{ item.name }}</p>
        <p>{{ item.description }}</p>
        <button class="button">Bérelje ki most!</button>
      </div>
    </div>
  </div>
</template>

<script>
import sarokcsiszolo from '@/photos/sarokcsiszolo.png';
import furogep from '@/photos/furogep.png';
import vesogep from '@/photos/vesogep.png';
import betonkevero from '@/photos/betonkevero.png';
import lezeres from '@/photos/lezeres.png';
import holegfuvo from '@/photos/holegfuvo.png';
import magasnyomasu from '@/photos/magasnyomasu.png';
import koszoru from '@/photos/koszoru.png';
import korfuresz from '@/photos/korfuresz.png';
import kompresszor from '@/photos/kompresszor.png';
import gervago from '@/photos/gervago.png';
import aszfaltvago from '@/photos/aszfaltvago.png';

export default {
  name: 'GardenView',
  data() {
    return {
      items: [
        {
          image: sarokcsiszolo,
          name: 'Sarokcsiszoló',
          description: 'Ez egy kiváló sarokcsiszoló.',
        },
        {
          image: furogep,
          name: 'Fúrógép',
          description: 'Ez egy kiváló rotációs kapa.',
        },
        {
          image: vesogep,
          name: 'Vésőgép',
          description: 'Ez egy másik kiváló sarokcsiszoló.',
        },
        {
          image: betonkevero,
          name: 'Betonkeverő',
          description: 'Ez egy másik kiváló rotációs kapa.',
        },
        {
          image: lezeres,
          name: 'Lézeres Szintező',
          description: 'Ez egy harmadik kiváló sarokcsiszoló.',
        },
        {
          image: holegfuvo,
          name: 'Hőlégfúvó',
          description: 'Ez egy harmadik kiváló rotációs kapa.',
        },
        {
          image: magasnyomasu,
          name: 'Magasnyomású Mosó',
          description: 'Ez egy negyedik kiváló sarokcsiszoló.',
        },
        {
          image: koszoru,
          name: 'Köszörű',
          description: 'Ez egy negyedik kiváló rotációs kapa.',
        },
        {
          image: korfuresz,
          name: 'Körfűrész',
          description: 'Ez egy ötödik kiváló sarokcsiszoló.',
        },
        {
          image: kompresszor,
          name: 'Kompresszor',
          description: 'Ez egy ötödik kiváló rotációs kapa.',
        },
        {
          image: gervago,
          name: 'Gérvágó Fűrész',
          description: 'Ez egy hatodik kiváló sarokcsiszoló.',
        },
        {
          image: aszfaltvago,
          name: 'Aszfaltvágó',
          description: 'Ez egy hatodik kiváló rotációs kapa.',
        },
      ],
    };
  },
};
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
}

.product-image {
  width: 100%;
  height: auto;
  object-fit: cover;
}

.grid {
  display: grid;
}

.grid-cols-3 {
  grid-template-columns: repeat(3, 1fr);
}

.gap-4 {
  gap: 1rem;
}

.back-button {
  background-color: #858a91;
  color: black;
  padding: 0.5rem 1rem;
  border-radius: 0.25rem;
  text-decoration: none;
}

.button {
  background-color: #858a91;
  color: black;
  padding: 0.5rem 1rem;
  border-radius: 0.25rem;
  text-decoration: none;
}

</style>
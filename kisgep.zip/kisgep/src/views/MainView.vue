<template>
  <div class="container mx-auto p-4 flex">
    <!-- Sidebar (Left) -->
    <aside class="w-1/4 p-4 bg-gray-100 fixed left-0 top-0 h-full">
      <nav class="relative">
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kategóriák
          </button>
          <ul class="dropdown-menu bg-gray-200">
            <li>
              <router-link class="dropdown-item" to="/construction">Építőipari Gépek</router-link>
            </li>
            <li>
              <router-link class="dropdown-item" to="/garden">Kerti Gépek</router-link>
            </li>
            <li>
              <router-link class="dropdown-item" to="/woodandmetal">Fa és Fémipari Gépek</router-link>
            </li>
          </ul>
        </div>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-grow p-4 ml-[25%]">
      <!-- Ide jöhet a fő tartalom -->
      <p>Ez itt a fő tartalom.</p>
    </main>

    <!-- Sidebar (Right) -->
    <aside class="w-1/4 p-4 bg-gray-100 fixed right-0 top-0 h-full">
      <h2 class="text-lg font-bold text-right">E Heti Legnépszerűbb Termékek</h2>
      <div class="mt-4 w-full">
        <div class="border border-black p-2 mb-4 text-center w-full">
          <img src="C:\Users\banhi\OneDrive\Desktop\kisgep\src\photos\rotacioskapa.png" alt="Termék" class="product-image mx-auto">
          <button class="bg-black text-white px-4 py-2 mt-2 w-full">Bérelje ki most!</button>
        </div>
        <div class="border border-black p-2 text-center w-full">
          <img src="C:\Users\banhi\OneDrive\Desktop\kisgep\src\photos\sarokcsiszolo.png" alt="Termék" class="product-image mx-auto">
          <button class="bg-black text-white px-4 py-2 mt-2 w-full">Bérelje ki most!</button>
        </div>
      </div>
    </aside>
  </div>
</template>

<script>
export default {
  data() {
    return {
      menuOpen: false,
    };
  },
  methods: {
    toggleMenu() {
      this.menuOpen = !this.menuOpen;
    },
  },
};
</script>

<style scoped>
/* Alapértelmezett stílusok */
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
}

/* Sidebar stílusok */
aside {
  width: 25%; /* 1/4 szélesség */
}

/* Jobb oldali sidebar */
aside.fixed-right {
  position: fixed;
  right: 0;
  top: 0;
  height: 100vh;
  background-color: #858a91; 
}

/* Fő tartalom */
main {
  margin-left: 25%; /* Bal oldali sidebar szélessége */
}

/* Termék képek */
.product-image {
  width: 200px;
  height: 200px;
  object-fit: cover;
}
</style>
<template>
    <div class="basket-view">
      <h1>Kosár Tartalma</h1>
      <div class="container"></div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'BasketView'
  };
  </script>
  
  <style scoped>
  .basket-view {
    background-color: rgb(209, 219, 225);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    text-align: center;
    padding-top: 20px;
  }
  
  .basket-view h1 {
    color: #333;
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 20px;
  }
  
  .container {
    width: 100%;
    max-width: 1200px;
    background-color: white;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    padding: 20px;
    min-height: 400px; 
  }
  </style>
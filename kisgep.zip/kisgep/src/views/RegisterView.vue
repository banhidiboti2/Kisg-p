<template>
  <div class="auth-container">
    <div class="auth-box">
      <div class="toggle-buttons">
        <button class="toggle-btn active">Regisztráció</button>
        <button class="toggle-btn">Bejelentkezés</button>
      </div>
      <h2>Regisztráció</h2>
      <form @submit.prevent="register">
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" v-model="email" id="email" required />
        </div>
        <div class="form-group">
          <label for="password">Jelszó</label>
          <input type="password" v-model="password" id="password" required />
        </div>
        <div class="form-group">
          <label for="confirmPassword">Jelszó megerősítése</label>
          <input type="password" v-model="confirmPassword" id="confirmPassword" required />
        </div>
        <button class="btn" type="submit">Regisztráció</button>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      password: '',
      confirmPassword: ''
    };
  },
  methods: {
    register() {
      if (this.password !== this.confirmPassword) {
        alert('A jelszavak nem egyeznek!');
        return;
      }
      console.log('Email:', this.email);
      console.log('Jelszó:', this.password);
    }
  }
};
</script>

<style scoped>
.auth-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(to right, #cfd9df, #e2ebf0);
}

.auth-box {
  background: rgb(255, 255, 255);
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 450px;
  text-align: center;
  position: relative;
}

.toggle-buttons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-bottom: 1rem;
}

.toggle-btn {
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: bold;
  cursor: pointer;
  background: #f1f1f1;
  transition: 0.3s ease;
}

.toggle-btn.active {
  background: #ffcc00;
}

h2 {
  font-size: 1.8rem;
  margin-bottom: 1rem;
  color: #333;
}

.form-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-bottom: 1.5rem;
}

label {
  font-size: 0.9rem;
  color: #666;
  margin-bottom: 5px;
}

input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1rem;
  outline: none;
}

.btn {
  width: 100%;
  padding: 12px;
  background: #ffcc00;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: bold;
  color: #333;
  cursor: pointer;
  transition: 0.3s ease;
}

.btn:hover {
  background: #ffdb4d;
}
</style>

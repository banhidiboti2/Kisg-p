import { createRouter, createWebHistory } from 'vue-router'
import MainView from '../views/MainView.vue'
import LoginView from '../views/LoginView.vue'
import RegisterView from '../views/RegisterView.vue'
import BasketView from '../views/BasketView.vue'
import ConstructionView from '@/views/ConstructionView.vue' // Hozzáadva
import GardenView from '@/views/GardenView.vue'
import WoodAndMetalView from '@/views/WoodAndMetalView.vue'

const routes = [
  {
    path: '/',
    name: 'Main',
    component: MainView
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginView
  },
  {
    path: '/register',
    name: 'Register',
    component: RegisterView
  },
  {
    path: '/basket',
    name: 'Basket',
    component: BasketView
  },
  {
    path: '/construction',
    name: 'ConstructionView',
    component: ConstructionView,
  },
  {
    path: '/garden',
    name: 'GardenView',
    component: GardenView,
  },
  {
    path: '/woodandmetal',
    name: 'WoodAndMetalView',
    component: WoodAndMetalView,
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router